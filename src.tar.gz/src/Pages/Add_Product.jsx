import axios from 'axios';
import React, { useState } from 'react'

function Add_Product() {

  const[formvalue,setformvalue]=useState({
    id:"",
    img:"",
    name:"",
    email:"",
    mobile:"",
  });
  
  const onchange=(e)=>{
    setformvalue({...formvalue,id:new Date().getTime().toString(),[e.target.name]:e.target.value});
    console.log(formvalue); 
  }

  const validation=()=>{
    var result=true;
    if(formvalue.img=="" || formvalue.img==null){
      result=false;
      alert('Enter image Url');
      return false;
    }
    if(formvalue.name=="" || formvalue.name==null){
      result=false;
      alert('Enter Your name');
      return false;
    }
    if(formvalue.email=="" || formvalue.email==null){
      result=false;
      alert('Enter Email');
      return false;
    }
    if(formvalue.mobile=="" || formvalue.mobile==null){
      result=false;
      alert('Enter Number');
      return false;
    }
    return result;
  }

  const onsubmit=async(e)=>{
    e.preventDefault();
    if(validation()){
      const res=await axios.post(`http://localhost:3000/Product`,formvalue);
      setformvalue({...formvalue,img:"",name:"",email:"",mobile:""})
      console.log(res);
    }
  }



  return (
    <div className="content-wrapper">
    <div className='appointment'>
      <div className="container">
        <div className='row'>
          <div className='col-md-12'>
            <div className='titlepage text_align_center'>
              <h2>
                Products
              </h2>
            </div>
          </div>
          <div className='container p-5'>
           <form>
            <div className='form-group pb-3 rounded-circle'>
              <label htmlFor='Image'>Image Url</label>
              <input type="url"  className='form-control' name='img' onChange={onchange} value={formvalue.img} placeholder='Enter Img Url'></input>
            </div>
            <div className='form-group pb-3 rounded-circle'>
              <label htmlFor='name'>Name</label>
              <input type="text" className='form-control' name='name' onChange={onchange} value={formvalue.name} placeholder='Enter Nmae'></input>
            </div>
            <div className='form-group pb-3 rounded-circle'>
              <label htmlFor='email'>Email address</label>
              <input type="email" className='form-control' name='email' onChange={onchange} value={formvalue.email} placeholder='Enter Email Id'></input>
            </div>
            <div className='form-group pb-3 rounded-circle'>
              <label htmlFor='mobile'>Number</label>
              <input type="number" className='form-control' name='mobile' onChange={onchange} value={formvalue.mobile} placeholder='Mobile'></input>
            </div>
            <button type='sumbit' className='btn btn-primary' onClick={onsubmit}>Submit</button>
           </form> 
          </div>    

        </div>

      </div>
      </div>  
    
    </div>
  )
}

export default Add_Product