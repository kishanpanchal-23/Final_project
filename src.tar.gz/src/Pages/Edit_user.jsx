import axios from 'axios';
import React, {useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom';

function Edit_user() {

    const redirect = useNavigate();

    useEffect(()=>{
        onedit();
    },[]);
    
    //Edit-Update
   const [formvalue,setformvalue]= useState({
    name:"",
    email:"",
    mobile:"",
    password:'',
   });

   const onedit = async () => {
   const res = await axios.get(`http://localhost:3000/user/${id}`);
   setformvalue({...formvalue,name:res.data.name,email:res.data.email,mobile:res.data.mobile,password:res.data.password})
  } 

  const onchange=(e)=>{
    setformvalue({...formvalue,[e.target.name]:e.target.value});
    console.log(formvalue);
  }

  const validation=()=>{
    let result = true;
    if(formvalue.name == "" || formvalue.name == null){
        result = false;
        alert("Name field is required !");
        return false;
    }
    if(formvalue.email == "" || formvalue.email == null){
        result = false;
        alert("Email field is required !");
        return false;
    } 
    if(formvalue.mobile == "" || formvalue.mobile == null){
      result = false;
      alert("Mobile field is required !");
      return false;
    }
    if(formvalue.password == "" || formvalue.password == null){
        result = false;
        alert("Password field is required !");
        return false;
    }
    return result;
  }
   
  const {id}=useParams();

   const onupdate = async(e)=>{
    if (validation()){
        e.preventDefault();
        await axios.patch(`http://localhost:3000/user/${id}`, formvalue)
        .then((res)=>{
            console.log(res);
            if(res.status  == 200){
              setformvalue({...formvalue,name:"",email:"",mobile:"",password:""});
              redirect('/manageuser')
              alert('Update successfull');
            }
        })
    }
   }
  

  return (
    <div className="login-box">
  <div className="login-box-body">
    <h2 className="login-box-msg">Edit Profile</h2>
    <form>
    <div className="form-group col-md-12 mb-3">
        <label htmlFor="inputname">Name</label>
        <input type="text" value={formvalue.name} onChange={onchange} className="form-control mt-1" id="name" name="name" placeholder="Name" />
    </div>
    <div className="form-group col-md-12 mb-3">
        <label htmlFor="inputemail">Email</label>
        <input type="email" value={formvalue.email} onChange={onchange} className="form-control mt-1" id="email" name="email" placeholder="Email" />
    </div>
    <div className="form-group col-md-12 mb-3">
        <label htmlFor="inputnumber">Mobile</label>
        <input type="Number" value={formvalue.mobile} onChange={onchange} className="form-control mt-1" id="mobile" name="mobile" placeholder="Mobile"/>
    </div>
    <div className="form-group col-md-12 mb-3">
        <label htmlFor="inputpassword">Password</label>
        <input type="password" value={formvalue.password} onChange={onchange} className="form-control mt-1" id="password" name="password" placeholder="Password"/>
    </div>
      <div className="row">
        <div className="col-xs-4">
          <button type="submit" className="btn btn-success btn-block btn-flat" onClick={onupdate}>Save</button>
        </div>{/* /.col */}
      </div>
    </form>
  </div>{/* /.login-box-body */}
</div>
   )
  }
  export default Edit_user



