import axios from 'axios';
import React, { useEffect, useState } from 'react'
import {  useNavigate } from 'react-router-dom';

function Manage_user() {

    const redirect=useNavigate();

    const [data,setData]=useState([]);

    useEffect(() => {
        fetchdata();
    },[])

    const fetchdata= async() => {
        const res = await axios.get(`http://localhost:3000/user`)
        setData(res.data);
    }

    //delete
    const ondelete= async (id) =>{
          const res = await axios.delete(`http://localhost:3000/user/${id}`);
          fetchdata(res);
    }

    //update status
    const updatestatus= async(id)=>{
        const res=await axios.get(`http://localhost:3000/user/${id}`);
        if(res.data.status=="block"){
            await axios.patch(`http://localhost:3000/user/${id}`,{status:'unblock'});
            fetchdata();
        }
        else{
            await axios.patch(`http://localhost:3000/user/${id}`,{status:"block"});
            fetchdata();
        }
    }

  return (
    <div>
         <div className="main-footer"> 
            <div className="card shadow mb-4">
                <div className="container my-auto">
                    <h6 className="m-0 font-weight-bold text-primary">DataTables Example</h6>
                </div>
                <div className="card-body">
                    <div className="table-responsive">
                        <table className="table table-bordered" id="dataTable" width="100%" cellSpacing={0}>
                           <thead>
                            <tr>
                                <td>id</td>
                                <td>Name</td>
                                <td>Email</td>
                                <td>Password</td>
                                <td>Mobile</td>
                                <td>EDIT</td>
                                <td>status</td>
                                <td>DELETE</td>
                            </tr>
                           </thead>
                           <tbody>
                           {
                            data.map((item,index,ent)=>{
                                return(
                                    <tr>
                                        <td>{item.id}</td>
                                        <td>{item.name}</td>
                                        <td>{item.email}</td>
                                        <td>{item.password}</td>
                                        <td>{item.mobile}</td>
                                        <td><button class="btn btn-success btn-sm rounded-0 text-center " type="button" data-toggle="tooltip" data-placement="top" onClick={()=>{redirect('/edituser/'+item.id)}} title="Edit"><i class="fa fa-edit"></i>Edit</button></td>
                                        <td><button className='btn btn-primary' onClick={()=>updatestatus(item.id)}>{item.status}</button></td>   
                                        <td><button className='btn btn-danger' type='button' onClick={()=>{ondelete(item.id)}}>Delete</button></td>
                                    </tr>
                                
                                )
                            })
                           }
                           </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>
  )
}

export default Manage_user