import Login from "./Pages/Login";
import {BrowserRouter,Routes,Route} from 'react-router-dom'
import Header from "./Component/Header";
import Footer from "./Component/Footer";
import Dashboard from "./Pages/Dashboard";
import Manage_user from "./Pages/Manage_user";
import Manage_contact from "./Pages/Manage_contact";
import View_product from "./Pages/View_product";
import Add_Product from "./Pages/Add_Product";
import Edit_user from "./Pages/Edit_user";


function App() {
  return (
    <BrowserRouter>
       <Routes>
         <Route path="/" index element={<> <Login/> </>}></Route>
         <Route path="/dashboard"  element={<> <Header/> <Dashboard/> <Footer/> </>}></Route>
         <Route path="/manageuser" element={<> <Header/> <Manage_user/> <Footer/> </>}></Route>
         <Route path="/edituser/:id" element={<> <Header/> <Edit_user/> <Footer/> </>}></Route>
         <Route path="/manageContact" element={<> <Header/> <Manage_contact/> <Footer/> </>}></Route>
         <Route path="/viewProduct" element={<> <Header/> <View_product/> <Footer/> </>}></Route>
         <Route path="/addProduct" element={<> <Header/> <Add_Product/> <Footer/> </>}></Route>
        </Routes>
    </BrowserRouter>

  );
}

export default App;
